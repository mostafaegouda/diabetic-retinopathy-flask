const express = require("express");
const bodyParser = require("body-parser");
const fs = require("fs");
const app = express();
app.use(bodyParser.json());
const port = 3000;
const host = "localhost";

app.get("/", (req, res) => {
  res.send("Hello World!");
});

app.post("/addPatient", (req, res) => {
  const { name, national_id, phone, address } = req.body;
  //append to csv file
  const csv = `${name},${national_id},${phone},${address}\n`;
  fs.appendFile("patients.csv", csv, (err) => {
    if (err) {
      console.error(err);
    }
  });
  res.send("Patient added successfully");
});

app.get("/getPatients", (req, res) => {
  const csv = require("csvtojson");
  csv()
    .fromFile("patients.csv")
    .then((jsonObj) => {
      res.send(jsonObj);
    });
});

app.listen(port, host, () => {
  console.log(`Server running at http://${host}:${port}/`);
});
